export const FireBaseConfig = {
  apiKey: "AIzaSyDcZuMhw2Ee94H5DFE6lEPk0j0bqRFI8kc",
  authDomain: "sculpcart.firebaseapp.com",
  databaseURL: "https://sculpcart.firebaseio.com",
  projectId: "sculpcart",
  storageBucket: "sculpcart.appspot.com",
  messagingSenderId: "398000214582"
};
